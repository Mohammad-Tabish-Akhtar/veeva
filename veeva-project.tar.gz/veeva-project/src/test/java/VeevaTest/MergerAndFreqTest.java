package VeevaTest;


import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.Test;

import Veeva.FrequencyCounter;
import Veeva.Merger;

public class MergerAndFreqTest implements SparkSessionTestWrapper {

	@Test
    public void MyChecker() {
        List<String[]> stringAsList1 = new ArrayList<>();
        stringAsList1.add(new String[] { "William" });
        stringAsList1.add(new String[] { "Brook" });
        
        List<String[]> stringAsList2 = new ArrayList<>();
        stringAsList1.add(new String[] { "Brook" });
        stringAsList1.add(new String[] { "Silvain" });
        
        List<String[]> result = new ArrayList<>();
        result.add(new String[] { "William" });
        result.add(new String[] { "Brook" });
        result.add(new String[] { "Brook" });
        result.add(new String[] { "Silvain" });

        JavaSparkContext sparkContext = new JavaSparkContext(spark.sparkContext());

        JavaRDD<Row> rowRDD1 = sparkContext
                .parallelize(stringAsList1)
                .map((String[] row) -> RowFactory.create(row));
        JavaRDD<Row> rowRDD2 = sparkContext
                .parallelize(stringAsList2)
                .map((String[] row) -> RowFactory.create(row));
        JavaRDD<Row> rowRDDres = sparkContext
                .parallelize(result)
                .map((String[] row) -> RowFactory.create(row));
        // Create schema
        StructType schema = DataTypes
                .createStructType(new StructField[] {
                        DataTypes.createStructField("names", DataTypes.StringType, false)
                });

        Dataset<Row> df1 = spark.sqlContext().createDataFrame(rowRDD1, schema).toDF();
        Dataset<Row> df2 = spark.sqlContext().createDataFrame(rowRDD2, schema).toDF();
        Merger merges = new Merger();
        Dataset<Row> r1 = merges.myMerger(df1,df2);
        assertEquals(4,r1.count());
        FrequencyCounter freq=new FrequencyCounter();
        Dataset<Row> r2=freq.Frequency(r1);
        assertEquals(2, r2.agg(functions.max(r2.col("count"))).collectAsList().get(0).getLong(0));
        assertEquals(1, r2.agg(functions.min(r2.col("count"))).collectAsList().get(0).getLong(0));
}
}