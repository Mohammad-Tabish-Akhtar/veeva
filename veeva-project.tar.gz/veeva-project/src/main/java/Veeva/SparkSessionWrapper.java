package Veeva;

import org.apache.spark.sql.SparkSession;

public interface SparkSessionWrapper {
	SparkSession spark = SparkSession
            .builder()
            .appName("Build a DataFrame from Scratch")
            .master("local[*]")
            .getOrCreate();
	}