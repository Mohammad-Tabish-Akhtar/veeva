package Veeva;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class Creator implements SparkSessionWrapper {

    public static void main(String arg[]) {

        // Create schema
        StructType schema = DataTypes
                .createStructType(new StructField[] {
                        DataTypes.createStructField("names", DataTypes.StringType, false)
                });

        Dataset<Row> basefile = spark.sqlContext().read().schema(schema).text("/home/a/Veeva-names/names-2000-01-01.txt");
        Dataset<Row> newfile = spark.sqlContext().read().schema(schema).text("/home/a/Veeva-names/names-2000-01-02.txt");
        Merger merges = new Merger();
        Dataset<Row> MergedDataset=merges.myMerger(basefile, newfile);
        FrequencyCounter Freq=new FrequencyCounter();
        Dataset<Row> Frequency=Freq.Frequency(MergedDataset);
        Frequency.show();
        newfile.coalesce(1).write().mode(SaveMode.Append).text("/home/a/Veeva-names");
    }
}
