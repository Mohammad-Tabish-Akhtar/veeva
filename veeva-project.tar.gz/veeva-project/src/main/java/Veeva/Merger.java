package Veeva;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class Merger {
	    public Dataset<Row> myMerger(Dataset<Row> df1,Dataset<Row> df2){
	    	Dataset<Row> df3=df1.union(df2);
	    	df3.show();
	        return df3;
	    }
}