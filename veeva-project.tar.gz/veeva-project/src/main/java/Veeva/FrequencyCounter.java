package Veeva;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class FrequencyCounter {
	    public Dataset<Row> Frequency(Dataset<Row> df1){
	    	Dataset<Row> df2=df1.groupBy("names").count();
	    	df2.show();
	        return df2;
	    }
}